<?php
/**
 * @package @package qrnfcgenerator
 */
require_once (strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/[+class-lowercase+].class.php');
class QRNFCLink_mysql extends QRNFCLink {}
?>