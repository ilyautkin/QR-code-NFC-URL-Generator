<?php
/**
 * @package qrnfcgenerator
 */
class QRNFCLink extends xPDOSimpleObject {}
?>