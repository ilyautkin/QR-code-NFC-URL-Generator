<?php
/**
 * @package seopro
 */
require_once dirname(__DIR__) . '/qrnfcvisit.class.php';

class QRNFCVisit_mysql extends QRNFCVisit
{

}