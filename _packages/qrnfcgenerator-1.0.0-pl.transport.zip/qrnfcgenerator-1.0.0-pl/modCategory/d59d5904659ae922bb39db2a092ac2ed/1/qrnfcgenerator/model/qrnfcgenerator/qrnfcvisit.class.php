<?php

/**
 * @package qrnfcgenerator
 */
class QRNFCVisit extends xPDOSimpleObject
{

}