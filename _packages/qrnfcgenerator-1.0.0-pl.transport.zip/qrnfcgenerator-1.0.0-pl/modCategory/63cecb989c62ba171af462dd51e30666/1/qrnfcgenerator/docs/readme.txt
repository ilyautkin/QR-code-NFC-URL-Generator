---------------------------------------
QRNFCGenerator
---------------------------------------

QRNFCGenerator is a MODX Extra developed by Sterc.

Please view https://github.com/Sterc/QR-code-NFC-URL-Generator for the readme.
