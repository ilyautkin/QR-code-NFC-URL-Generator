<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'bf19b0371be026ac60b99bff7978bedc',
      'native_key' => 'qrnfcgenerator',
      'filename' => 'modNamespace/090b20df02498c9ee19e20af18c463d3.vehicle',
      'namespace' => 'qrnfcgenerator',
    ),
    1 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8210012e8836da244183ebfa9b5d18be',
      'native_key' => 'qrnfcgenerator.encryption.encrypt_key',
      'filename' => 'modSystemSetting/cd1ecec96d887fdccc13f31134733103.vehicle',
      'namespace' => 'qrnfcgenerator',
    ),
    2 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '497d0767ea7a499ed424df918f0cc165',
      'native_key' => 'qrnfcgenerator.encryption.encrypt_iv',
      'filename' => 'modSystemSetting/0f1609cdfd80cb2cced383f90c29cfad.vehicle',
      'namespace' => 'qrnfcgenerator',
    ),
    3 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b5651e4eb29eea06bc3b1df333f9800',
      'native_key' => 'qrnfcgenerator.utm_campaign',
      'filename' => 'modSystemSetting/e75bdbf5f18a977bd2e6f13d9373bf86.vehicle',
      'namespace' => 'qrnfcgenerator',
    ),
    4 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd28528dcfe410b234db8c399857b1b1e',
      'native_key' => 'qrnfcgenerator.user_name',
      'filename' => 'modSystemSetting/0aafdaa132ae41a992e70aacd694943c.vehicle',
      'namespace' => 'qrnfcgenerator',
    ),
    5 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7eedef7e3c94529142cc74de071ce66',
      'native_key' => 'qrnfcgenerator.user_email',
      'filename' => 'modSystemSetting/042d6ab231df5361a90d52168771bada.vehicle',
      'namespace' => 'qrnfcgenerator',
    ),
    6 => 
    array (
      'vehicle_package' => '',
      'vehicle_class' => 'xPDO\\Transport\\xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2343f67830aad422fd9c8ddd9171e8fd',
      'native_key' => NULL,
      'filename' => 'modCategory/5e6c0dd7bb3cf51e7387444b57fe0718.vehicle',
      'namespace' => 'qrnfcgenerator',
    ),
  ),
);